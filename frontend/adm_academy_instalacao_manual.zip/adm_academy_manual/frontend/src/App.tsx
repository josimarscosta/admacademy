import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// Componentes principais
const Dashboard = () => (
  <div className="dashboard">
    <h1>Dashboard Adm Academy</h1>
    <div className="dashboard-content">
      <div className="dashboard-card">
        <h2>Trilhas de Aprendizado</h2>
        <p>8 trilhas disponíveis</p>
        <button className="btn-primary">Acessar</button>
      </div>
      <div className="dashboard-card">
        <h2>Simulados</h2>
        <p>12 simulados disponíveis</p>
        <button className="btn-primary">Iniciar</button>
      </div>
      <div className="dashboard-card">
        <h2>Desempenho</h2>
        <p>Média: 78%</p>
        <button className="btn-primary">Ver detalhes</button>
      </div>
    </div>
  </div>
);

const Login = () => (
  <div className="login-container">
    <div className="login-form">
      <h1>Adm Academy</h1>
      <h2>Preparação para o ENADE 2025</h2>
      <form>
        <div className="form-group">
          <label>Email</label>
          <input type="email" placeholder="Seu email institucional" />
        </div>
        <div className="form-group">
          <label>Senha</label>
          <input type="password" placeholder="Sua senha" />
        </div>
        <button type="submit" className="btn-primary">Entrar</button>
      </form>
      <div className="login-footer">
        <p>Esqueceu sua senha? <a href="#">Recuperar</a></p>
      </div>
    </div>
  </div>
);

const App: React.FC = () => {
  return (
    <Router>
      <div className="app">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
